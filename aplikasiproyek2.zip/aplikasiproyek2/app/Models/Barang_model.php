<?php namespace App\Models;
use CodeIgniter\Model;
 
class Barang_model extends Model
{
    protected $table = 'barang';
    // ambil data barang jika tidak ada id atau ada
    public function getBarang($id = false)
    {
        if($id === false){
            return $this->findAll();
        } else {
            return $this->getWhere(['id_barang' => $id]);
        }    
    }
    //tambah data barang
    public function insertBarang($data)
    {
        return $this->db->table($this->table)->insert($data);
    }

    public function updateBarang($data, $id)
    {
        return $this->db->table($this->table)->update($data, ['id_barang' => $id]);
    }
    //hapus data barang
    public function deleteBarang($id)
    {
        return $this->db->table($this->table)->delete(['id_barang' => $id]);
    } 
    // cek data barang berdasrkan id barang
    public function getData($id)
    {
        return $this->db->table($this->table)->getWhere(['id_barang' => $id])->getRowArray();
    }
    //cek data barang berdasarkan nama barang
    public function cekId($barang)
    { 
        return $this->db->table($this->table)->getWhere(['nama_barang' => $barang])->getRowArray();
    }
}