<?php namespace App\Models;
use CodeIgniter\Model;
 
class Suplier_model extends Model
{
    protected $table = 'suplier';
     
    public function insertSuplier($suplier)
    {
        return $this->db->table($this->table)->insert($suplier);
    }

    public function cekId($suplier)
    {
        return $this->db->table($this->table)->getWhere(['nama_suplier' => $suplier])->getRowArray();
    }
}