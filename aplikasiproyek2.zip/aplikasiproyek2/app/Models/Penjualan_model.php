<?php namespace App\Models;
use CodeIgniter\Model;
 
class penjualan_model extends Model
{
    protected $table = 'penjualan';
     
    public function getPenjualan($id = false)
    {
        if($id === false){
            return $this->table('penjualan')
                        ->join('konsumen', 'konsumen.id_konsumen = penjualan.id_konsumen')
                        ->get()
                        ->getResultArray();
        } else {
            return $this->table('penjualan')
                        ->join('konsumen', 'konsumen.id_konsumen = penjualan.id_konsumen')
                        ->where('penjualan.id_penjualan', $id)
                        ->get()
                        ->getRowArray();
        }  
    }

    public function insertPenjualan($data)
    {
        return $this->db->table($this->table)->insert($data);
    }
    public function updatePenjualan($data, $id)
    {
        return $this->db->table($this->table)->update($data, ['id_penjualan' => $id]);
    }
    public function deletePenjualan($id)
    {
        return $this->db->table($this->table)->delete(['id_penjualan' => $id]);
    } 
}