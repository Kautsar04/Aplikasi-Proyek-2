<?php namespace App\Models;
use CodeIgniter\Model;
 
class pembelian_model extends Model
{
    protected $table = 'pembelian';
     
    public function getPembelian($id = false)
    {
        if($id === false){
            return $this->table('pembelian')
                        ->join('suplier', 'suplier.id_suplier = pembelian.id_suplier')
                        ->join('barang', 'barang.id_barang = pembelian.id_barang')
                        ->get()
                        ->getResultArray();
        } else {
            return $this->table('pembelian')
                        ->join('suplier', 'suplier.id_suplier = pembelian.id_suplier')
                        ->join('barang', 'barang.id_barang = pembelian.id_barang')
                        ->where('pembelian.id_pembelian', $id)
                        ->get()
                        ->getRowArray();
        }  
    }

    public function insertPembelian($data)
    {
        return $this->db->table($this->table)->insert($data);
    }
    public function updatePembelian($data, $id)
    {
        return $this->db->table($this->table)->update($data, ['id_pembelian' => $id]);
    }
    public function deletePembelian($id)
    {
        return $this->db->table($this->table)->delete(['id_pembelian' => $id]);
    } 
}