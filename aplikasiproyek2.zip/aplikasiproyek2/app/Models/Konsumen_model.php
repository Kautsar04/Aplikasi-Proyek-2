<?php namespace App\Models;
use CodeIgniter\Model;
 
class konsumen_model extends Model
{
    protected $table = 'konsumen';
     
    public function insertkonsumen($konsumen)
    {
        return $this->db->table($this->table)->insert($konsumen);
    }
    public function cekId($konsumen)
    { 
        return $this->db->table($this->table)->getWhere(['nama_konsumen' => $konsumen])->getRowArray();
    }
    
}