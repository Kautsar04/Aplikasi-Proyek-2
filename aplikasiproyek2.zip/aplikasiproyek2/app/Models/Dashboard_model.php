<?php namespace App\Models;
use CodeIgniter\Model;
 
class Dashboard_model extends Model
{
    protected $table = 'penjualan';

    // hitung total data pada pembelian
    public function getCountPmbl()
    {
        return $this->db->table("pembelian")->countAll();
    }

    // hitung total data pada barang
    public function getCountBarang()
    {
        return $this->db->table("barang")->countAll();
    }

    // hitung total data pada user
    public function getCountUser()
    {
        return $this->db->table("users")->countAll();
    }
    // hitung total data pada penjualan
    public function getLatestPnjl()
    {
        return $this->table('penjualan')
            ->select('konsumen.nama_konsumen, penjualan.*')
            ->join('konsumen', 'konsumen.id_konsumen = penjualan.id_konsumen')
            ->orderBy('penjualan.id_penjualan', 'desc')
            ->limit(5)
            ->get()
            ->getResultArray();
    }
}