<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Penjualan_model;
use App\Models\Konsumen_model;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
 
class Penjualan extends Controller
{
    protected $helpers = [];

    public function __construct()
    {
        helper(['form']);
        $this->penjualan_model = new Penjualan_model();
        $this->konsumen_model = new Konsumen_model();
    }

    public function index()
    {
        $data['penjualan'] = $this->penjualan_model->getPenjualan();
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        echo view('penjualan/index', $data);
    }

    public function create()
    {
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        return view('penjualan/create');
    }

    public function store()
    {
        $validation =  \Config\Services::validation();

        $data = array(
            'nama_konsumen'         => $this->request->getPost('nama_konsumen'),
            'tanggal_penjualan'     => $this->request->getPost('tanggal_penjualan'),
            'total_penjualan'       => $this->request->getPost('total_penjualan'),
            'total_harga'           => $this->request->getPost('total_harga') * $this->request->getPost('total_penjualan')
        );

        //untuk cek data sudah terisi atau belum
        if($validation->run($data, 'tambahpenjualan') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('penjualan/create'));
        } else {
            $konsumen = array(
            'nama_konsumen'         =>$this->request->getPost('nama_konsumen')
            );
        
            if($validation->run($konsumen, 'cekkonsumen') == TRUE){
                $this->konsumen_model->insertKonsumen($konsumen);
            }
             
            $getdata = $this->konsumen_model->cekId($konsumen);
            if (isset($getdata)){
                $getid = $getdata['id_konsumen'];
            }

            $datalagi = [
                'id_konsumen'            => $getid,
                'tanggal_penjualan'     => $this->request->getPost('tanggal_penjualan'),
                'total_penjualan'       => $this->request->getPost('total_penjualan'),
                'total_harga'           => $this->request->getPost('total_harga')
            ];
            
            $simpan = $this->penjualan_model->insertPenjualan($datalagi);
            if($simpan)
            {
                session()->setFlashdata('success', 'Created data penjualan successfully');
                return redirect()->to(base_url('penjualan')); 
            }
        }
    }

    public function edit($id)
    {  
        $data['penjualan'] =  $this->penjualan_model->getPenjualan($id);

        echo view('penjualan/edit', $data);
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
    }

    public function update()
    {
        $id = $this->request->getPost('id_penjualan');

        $validation =  \Config\Services::validation();

        $data = array(
            'nama_konsumen'          => $this->request->getPost('nama_konsumen'),
            'tanggal_penjualan'     => $this->request->getPost('tanggal_penjualan'),
            'total_penjualan'       => $this->request->getPost('total_penjualan'),
            'total_harga'           => $this->request->getPost('total_harga')
        );

        if($validation->run($data, 'tambahpenjualan') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('penjualan/edit'));
        } else {
            $konsumen = array(
                'nama_konsumen'         =>$this->request->getPost('nama_konsumen')
            );
            if($validation->run($konsumen, 'cekkonsumen') == TRUE){
                $this->konsumen_model->insertKonsumen($konsumen);
            }
            $getdata = $this->konsumen_model->cekId($konsumen);
            if (isset($getdata)){
                $getkonsumen = $getdata['id_konsumen'];
            }

            $datalagi = [
                'id_konsumen'            => $getkonsumen,
                'tanggal_penjualan'     => $this->request->getPost('tanggal_penjualan'),
                'total_penjualan'       => $this->request->getPost('total_penjualan'),
                'total_harga'           => $this->request->getPost('total_harga')
            ];
            $ubah = $this->penjualan_model->updatePenjualan($datalagi, $id);
            if($ubah)
            {
                session()->setFlashdata('info', 'Updated Penjualan successfully');
                return redirect()->to(base_url('penjualan')); 
            }
        }
    }

    public function delete($id)
    {
        $hapus = $this->penjualan_model->deletePenjualan($id);
        if($hapus)
        {
            session()->setFlashdata('warning', 'Deleted penjualan successfully');
            return redirect()->to(base_url('penjualan/index')); 
        }
    }
    
    public function import()
    {
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        echo view('penjualan/import');
    }

    public function proses_import()
    {
        $validation =  \Config\Services::validation();
        $file = $this->request->getFile('trx_file');
        $data = array(
            'trx_file'           => $file,
        );

        if($validation->run($data, 'penjualan') == FALSE){

            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('penjualan/import'));
        
        } else {

            // ambil extension dari file excel
            $extension = $file->getClientExtension();
            
            // format excel 2007 ke bawah
            if('xls' == $extension){
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            // format excel 2010 ke atas
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }
            $spreadsheet = $reader->load($file);
            $data = $spreadsheet->getActiveSheet()->toArray();

            foreach($data as $idx => $row){
                
                // lewati baris ke 0 pada file excel
                // dalam kasus ini, array ke 0 adalahpara title
                if($idx == 0) {
                    continue;
                }
                
                // ambil id_konsumen dari excel
                $id_konsumen          = $row[0];
                // ambil tanggal_penjualan dari excel
                $tanggal_penjualan   = $row[1];
                // ambil total_penjualan dari excel
                $total_penjualan     = $row[2];
                // tampilkan harga barang berdasarkan id_barang menggunakan function getTrxPrice()
                $total_harga         = $row[3];

                $data = [
                    "id_konsumen"            => $id_konsumen,
                    "tanggal_penjualan"      => date('Y-m-d', strtotime($tanggal_penjualan)),
                    "total_penjualan"        => $total_penjualan,
                    "total_harga"            => $total_harga
                ];

                // $simpan = $this->penjualan_model->insertPenjualan($data);
            }

            if(isset($tanggal_penjualan))
            {
                session()->setFlashdata('success', 'Imported Penjualan successfully');
                return redirect()->to(base_url('penjualan')); 
            }
        }
    }

    public function export()
    {
        // ambil data Penjualan dari database
        $penjualan = $this->penjualan_model->getPenjualan();
        // panggil class Sreadsheet baru
        $spreadsheet = new Spreadsheet;
        // Buat custom header pada file excel
        $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A1', 'No')
                    ->setCellValue('B1', 'Konsumen')
                    ->setCellValue('C1', 'Tanggal Penjualan')
                    ->setCellValue('D1', 'Total Penjualan')
                    ->setCellValue('E1', 'Harga');
        // define kolom dan nomor
        $kolom = 2;
        $nomor = 1;
        // tambahkan data transaction ke dalam file excel
        foreach($penjualan as $data) {

            $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('A' . $kolom, $nomor)
                        ->setCellValue('B' . $kolom, $data['nama_konsumen'])
                        ->setCellValue('C' . $kolom, date('j F Y', strtotime($data['tanggal_penjualan'])))
                        ->setCellValue('D' . $kolom, number_format($data['total_penjualan']))
                        ->setCellValue('E' . $kolom, "Rp. ".($data['total_harga']));

            $kolom++;
            $nomor++;

        }
        // download spreadsheet dalam bentuk excel .xlsx
        $writer = new Xlsx($spreadsheet);

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Laporan_Penjualan.xlsx"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }
}