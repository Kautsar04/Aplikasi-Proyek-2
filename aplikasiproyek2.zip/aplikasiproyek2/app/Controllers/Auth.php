<?php namespace App\Controllers;
 
use App\Models\Auth_model;
use App\Models\Users_model;
 
class Auth extends BaseController
{
    protected $helper = [];

    public function __construct()
    {
        helper(['form']);
        $this->cek_login();
        $this->auth_model = new Auth_model();
        $this->users_model = new Users_model();
	}
    
    public function index()
    {
        if($this->cek_login() == TRUE){
			return redirect()->to('/dashboard');
		}
        echo view('auth/login');
    }

    public function login()
    {
        if($this->cek_login() == TRUE){
			return redirect()->to('/dashboard');
		}
        echo view('auth/login');
    }

    public function proses_login()
    {
        $validation =  \Config\Services::validation();

        $email  = $this->request->getPost('email');
        $pass   = $this->request->getPost('password');

        $data = [
            'email' => $email,
            'password' => $pass
        ]; 

        if($validation->run($data, 'authlogin') == FALSE){
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to('/auth/login');
        } else {

            $cek_login = $this->auth_model->cek_login($email);

            // email didapatkan
            if($cek_login == TRUE){

                // jika email dan password cocok
                if(password_verify($pass, $cek_login['password'])){

                    session()->set('email', $cek_login['email']);
                    session()->set('name', $cek_login['name']);
                    session()->set('level', $cek_login['level']);
                    session()->set('status', $cek_login['status']);
                    
                    return redirect()->to('/dashboard');          
                // email cocok, tapi password salah
                } else {
                    session()->setFlashdata('errors', ['' => 'Password yang Anda masukan salah']);
                    return redirect()->to('/auth/login');
                }
            } else {
                // email tidak cocok / tidak terdaftar
                session()->setFlashdata('errors', ['' => 'Email yang Anda masukan tidak terdaftar']);
                return redirect()->to('/auth/login');
            }
        }
    }

    public function tambahuser()
    {
        return view('auth/tambahuser');
        return view('_partials/sidebar/admin');
    }

    public function proses_tambahuser()
    {
        $validation =  \Config\Services::validation();

        $data = [
            'email'             => $this->request->getPost('email'),
            'name'              => $this->request->getPost('name'),
            'username'          => $this->request->getPost('username'),
            'level'             => $this->request->getPost('level'),
            'password'          => $this->request->getPost('password'),
            'confirm_password'  => $this->request->getPost('confirm_password')
        ];

        if($validation->run($data, 'authtambahuser') == FALSE){
            session()->setFlashdata('errors', $validation->getErrors());
            session()->setFlashdata('inputs', $this->request->getPost());
            return redirect()->to('/auth/tambahuser');
        } else {

            $datalagi = [
                'email'         => $this->request->getPost('email'),
                'name'          => $this->request->getPost('name'),
                'username'      => $this->request->getPost('username'),
                'password'      => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'status'        => "Active",
                'level'         => $this->request->getPost('level')
            ];

            $simpan = $this->auth_model->tambahuser($datalagi);

            if($simpan){
                session()->setFlashdata('success_tambahuser', 'Register Successfully');
                return redirect()->to('/auth/login');
            }

        }

    }

    public function Users()
    {
        $keyword            = $this->request->getGet('keyword');

        $data['keyword']    = $keyword;

        // filter
        $where      = [];
        $like       = [];
        $or_like    = [];

        if(!empty($keyword)){
            $where = ['users.id' => $keyword];
            $like   = ['users.username' => $keyword];
            $or_like   = ['users.name' => $keyword, 'users.email' => $keyword];
        }
        // end filter

        // paginate
        $paginate = 5;
        $data['users']   = $this->users_model->where($where)->like($like)->orLike($or_like)->paginate($paginate, 'users');
        $data['pager']      = $this->users_model->pager;

        // generate number untuk tetap bertambah meskipun pindah halaman paginate
        $nomor = $this->request->getGet('page_users');
        // define $nomor = 1 jika tidak ada get page_product
        if($nomor == null){
            $nomor = 1;
        }
        $data['nomor'] = ($nomor - 1) * $paginate;
        // end generate number

        echo view('auth/users', $data);
        echo view('_partials/sidebar/admin');
        
    }

    public function delete($id)
    {
        $hapus = $this->users_model->deleteUser($id);
        if($hapus)
        {
            session()->setFlashdata('warning', 'Deleted User successfully');
            return redirect()->to(base_url('auth/users')); 
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
}