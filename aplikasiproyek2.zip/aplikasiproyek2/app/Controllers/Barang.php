<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\Barang_model;
 
class Barang extends Controller
{
    protected $helpers = [];

    public function __construct()
    {
        helper(['form']);
        $this->barang_model = new Barang_model();
    }

    public function index()
    { 
        $keyword            = $this->request->getGet('keyword');

        $data['keyword']    = $keyword;

        // filter
        $where      = [];
        $like       = [];
        $or_like    = [];

        if(!empty($keyword)){
            $where = ['barang.nama_barang' || 'barang.harga' ||'barang.stok'];
            $like   = ['barang.nama_barang' => $keyword];
            $or_like   = ['barang.harga' => $keyword, 'barang.stok' => $keyword];
        }
        // end filter

        // paginate
        $paginate = 5;
        $data['barang']   = $this->barang_model->where($where)->like($like)->orLike($or_like)->paginate($paginate, 'barang');
        $data['pager']      = $this->barang_model->pager;

        // generate nomor halaman untuk tetap bertambah meskipun pindah halaman paginate
        $nomor = $this->request->getGet('page_barang');
        if($nomor == null){
            $nomor = 1;
        }
        $data['nomor'] = ($nomor - 1) * $paginate;

        echo view('barang/index', $data);
    }
 
    public function create()
    {
        return view('barang/create');
    }

    public function store()
    {
        $validation =  \Config\Services::validation();
        $data = array(
            'nama_barang'          => $this->request->getPost('nama_barang'),
            'harga'                => $this->request->getPost('harga'),
            'stok'                 => $this->request->getPost('stok')
        );
        if($validation->run($data, 'barang') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('barang/create'));
        } else {
            $simpan = $this->barang_model->insertBarang($data);
            if($simpan)
            {
                session()->setFlashdata('success', 'Created Barang successfully');
                return redirect()->to(base_url('barang')); 
            }
        }
    }
    


    public function edit($id)
    {  
        $model = new Barang_model();
        $data['barang'] = $model->getBarang($id)->getRowArray();
        echo view('barang/edit', $data);
    }


    public function update()
    {
        $id = $this->request->getPost('id_barang');
        $validation =  \Config\Services::validation();
        $data = array(
            'nama_barang'     => $this->request->getPost('nama_barang'),
            'harga'   => $this->request->getPost('harga'),
            'stok'   => $this->request->getPost('stok'),
        );
        if($validation->run($data, 'barang') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('barang/edit/'.$id));
        } else {
            $model = new Barang_model();
            $ubah = $model->updateBarang($data, $id);
            if($ubah)
            {
                session()->setFlashdata('info', 'Updated Barang successfully');
                return redirect()->to(base_url('barang')); 
            }
        }
    }
 
    public function delete($id)
    {
        $hapus = $this->barang_model->deleteBarang($id);
        if($hapus)
        {
            session()->setFlashdata('warning', 'Deleted Barang successfully');
            return redirect()->to(base_url('barang')); 
        }
    }
}