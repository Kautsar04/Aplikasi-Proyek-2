<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Barang_model;
use App\Models\Pembelian_model;
use App\Models\Suplier_model;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
 
class Pembelian extends Controller
{
    protected $helpers = [];

    public function __construct()
    {
        helper(['form']);
        $this->pembelian_model = new Pembelian_model();
        $this->barang_model = new Barang_model();
        $this->suplier_model = new Suplier_model();
    }

    public function index()
    {
        $data['pembelian'] = $this->pembelian_model->getPembelian();
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        echo view('pembelian/index', $data);
    }

    public function create()
    {
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        $barang = $this->barang_model->findAll();
        $data['barang'] = ['' => 'Pilih Barang'] + array_column($barang, 'nama_barang', 'id_barang');
        return view('pembelian/create', $data);
        
    }

    public function store()
    {
        $validation =  \Config\Services::validation();

        $data = array(
            'id_barang'             => $this->request->getPost('id_barang'),
            'nama_suplier'          => $this->request->getPost('nama_suplier'),
            'tanggal_pembelian'     => $this->request->getPost('tanggal_pembelian'),
            'total_pembelian'       => $this->request->getPost('total_pembelian'),
            'total_harga'           => $this->request->getPost('total_harga')
        );

        if($validation->run($data, 'tambahpembelian') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('pembelian/create'));
        } else {
            // array untuk cek suplier
            $suplier = array(
                'nama_suplier'         =>$this->request->getPost('nama_suplier')
            );
            // cek ada atau tidak data suplier
            if($validation->run($suplier, 'ceksuplier') == TRUE){
                $this->suplier_model->insertSuplier($suplier);
            }
            // ambil data suplier
            $getdata = $this->suplier_model->cekId($suplier);
            if (isset($getdata)){
                $getsuplier = $getdata['id_suplier'];
            }

            $datalagi = [
                'id_barang'             => $this->request->getPost('id_barang'),
                'id_suplier'            => $getsuplier,
                'tanggal_pembelian'     => $this->request->getPost('tanggal_pembelian'),
                'total_pembelian'       => $this->request->getPost('total_pembelian'),
                'total_harga'           => $this->request->getPost('total_harga')
            ];

            $simpan = $this->pembelian_model->insertPembelian($datalagi);
            if($simpan)
            {
                session()->setFlashdata('success', 'Created data pembelian successfully');
                return redirect()->to(base_url('pembelian')); 
            }
        }
    }

    public function edit($id)
    {  
        $barang = $this->barang_model->findAll();
        $data['barang'] = ['' => 'Pilih Barang'] + array_column($barang, 'nama_barang', 'id_barang');
        $data['pembelian'] =  $this->pembelian_model->getPembelian($id);
        echo view('pembelian/edit', $data);
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
    }

    public function update()
    {
        $id = $this->request->getPost('id_pembelian');

        $validation =  \Config\Services::validation();

        $data = array(
            'id_barang'             => $this->request->getPost('id_barang'),
            'nama_suplier'          => $this->request->getPost('nama_suplier'),
            'tanggal_pembelian'     => $this->request->getPost('tanggal_pembelian'),
            'total_pembelian'       => $this->request->getPost('total_pembelian'),
            'total_harga'           => $this->request->getPost('total_harga')
        );

        if($validation->run($data, 'tambahpembelian') == FALSE){
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            $row = $this->request->getPost('id_pembelian');
            return redirect()->to(base_url('pembelian/edit/'.$row));
        } else {
            $suplier = array(
                'nama_suplier'         =>$this->request->getPost('nama_suplier')
            );
            if($validation->run($suplier, 'ceksuplier') == TRUE){
                $this->suplier_model->insertSuplier($suplier);
            }
            $getdata = $this->suplier_model->cekId($suplier);
            if (isset($getdata)){
                $getsuplier = $getdata['id_suplier'];
            }

            $datalagi = [
                'id_barang'             => $this->request->getPost('id_barang'),
                'id_suplier'            => $getsuplier,
                'tanggal_pembelian'     => $this->request->getPost('tanggal_pembelian'),
                'total_pembelian'       => $this->request->getPost('total_pembelian'),
                'total_harga'           => $this->request->getPost('total_harga')
            ];
            $ubah = $this->pembelian_model->updatePembelian($datalagi, $id);
            if($ubah)
            {
                session()->setFlashdata('info', 'Updated Pembelian successfully');
                return redirect()->to(base_url('pembelian')); 
            }
        }
    }
 
    public function delete($id)
    {
        $hapus = $this->pembelian_model->deletePembelian($id);
        if($hapus)
        {
            session()->setFlashdata('warning', 'Deleted Pembelian successfully');
            return redirect()->to(base_url('pembelian')); 
        }
    }

    public function import()
    {
        if(session()->get('level') == "Admin"){
            echo view('_partials/sidebar/admin');
        }elseif(session()->get('level') == "User"){
            echo view('_partials/sidebar/karyawan');
        }
        echo view('pembelian/import');
    }

    public function proses_import()
    {
        $validation =  \Config\Services::validation();

        $file = $this->request->getFile('trx_file');

        $data = array(
            'trx_file'           => $file,
        );

        if($validation->run($data, 'pembelian') == FALSE){

            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('pembelian/import'));
        
        } else {

            // ambil extension dari file excel
            $extension = $file->getClientExtension();
            
            // format excel 2007 ke bawah
            if('xls' == $extension){
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            // format excel 2010 ke atas
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }
            
            $spreadsheet = $reader->load($file);
            $data = $spreadsheet->getActiveSheet()->toArray();

            foreach($data as $idx => $row){
                
                // lewati baris ke 0 pada file excel
                // dalam kasus ini, array ke 0 adalahpara title
                if($idx == 0) {
                    continue;
                }
                
                // ambil id_barang dari excel
                $id_barang           = $row[0];
                // ambil id_suplier dari excel
                $id_suplier          = $row[1];
                // ambil tanggal_pembelian dari excel
                $tanggal_pembelian   = $row[2];
                // ambil total_pembelian dari excel
                $total_pembelian     = $row[3];
                // tampilkan harga barang berdasarkan id_barang menggunakan function getTrxPrice()
                $total_harga         = $row[4];


                $databarang[]= $nama_suplier;
                // ambil data barang
                $getbarang = $this->barang_model->cekId($databarang);
                if (isset($getbarang)){
                    $id_barang = $getbarang['id_barang'];
                }

                $datasuplier[]= $nama_suplier;
                // ambil data suplier
                $getsuplier = $this->suplier_model->cekId($nama_suplier);
                if (isset($getsuplier)){
                    $id_suplier = $getsuplier['id_suplier'];
                }else{
                    $this->suplier_model->insertSuplier($datasuplier);
                    $id_suplier = $getsuplier['id_suplier'];
                }

                $data = [
                    "id_barang"              => $id_barang,
                    "id_suplier"             => $id_suplier,
                    "tanggal_pembelian"      => date('Y-m-d', strtotime($tanggal_pembelian)),
                    "total_pembelian"        => $total_pembelian,
                    "total_harga"            => $total_harga
                ];

                // $simpan = $this->pembelian_model->insertPembelian($data);
            }

            if(isset($total_harga))
            {
                session()->setFlashdata('success', 'Imported Pembelian successfully');
                return redirect()->to(base_url('pembelian')); 
            }
        }
    }

    public function export()
    {
        // ambil data Pembelian dari database
        $pembelian = $this->pembelian_model->getPembelian();
        // panggil class Sreadsheet baru
        $spreadsheet = new Spreadsheet;
        // Buat custom header pada file excel
        $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A1', 'No')
                    ->setCellValue('B1', 'Barang')
                    ->setCellValue('C1', 'Suplier')
                    ->setCellValue('D1', 'Tanggal Pembelian')
                    ->setCellValue('E1', 'Total Pembelian')
                    ->setCellValue('F1', 'Harga');
        // menetapkan kolom dan nomor
        $kolom = 2;
        $nomor = 1;
        // tambahkan data transaction ke dalam file excel
        foreach($pembelian as $data) {

            $spreadsheet->setActiveSheetIndex(0)
                        ->setCellValue('A' . $kolom, $nomor)
                        ->setCellValue('B' . $kolom, $data['nama_barang'])
                        ->setCellValue('C' . $kolom, $data['nama_suplier'])
                        ->setCellValue('D' . $kolom, date('j F Y', strtotime($data['tanggal_pembelian'])))
                        ->setCellValue('E' . $kolom, number_format($data['total_pembelian']))
                        ->setCellValue('F' . $kolom, number_format($data['total_harga']));

            $kolom++;
            $nomor++;

        }
        // download spreadsheet dalam bentuk excel .xlsx
        $writer = new Xlsx($spreadsheet);

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Laporan_Pembelian.xlsx"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }
}