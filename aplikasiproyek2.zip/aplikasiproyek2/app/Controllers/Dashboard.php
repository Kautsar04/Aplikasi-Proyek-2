<?php namespace App\Controllers;

use App\Models\Dashboard_model;

class Dashboard extends BaseController
{
	public function __construct()
    {
		$this->cek_login();
		$this->dashboard_model = new Dashboard_model();
	}
	
	public function index()
	{
		if($this->cek_login() == FALSE){
			session()->setFlashdata('error_login', 'Silahkan login terlebih dahulu untuk mengakses data');
			return redirect()->to('/auth/login');
		}
		if(session()->get('level') == "Admin"){

			$data['total_pembelian']		= $this->dashboard_model->getCountPmbl();
			$data['total_penjualan']		= $this->dashboard_model->getCountPnjl();
			$data['total_barang']			= $this->dashboard_model->getCountBarang();
			$data['total_user']				= $this->dashboard_model->getCountUser();

			$chart['grafik']			= $this->dashboard_model->getGrafik();

			echo view('dashboard/admin', $data);
			echo view('_partials/footer', $chart);
			echo view('_partials/sidebar/admin');
		}elseif(session()->get('level') == "User"){
			
			$data['total_pembelian']		= $this->dashboard_model->getCountPmbl();
			$data['total_penjualan']		= $this->dashboard_model->getCountPnjl();
			$data['latest_penjualan']		= $this->dashboard_model->getLatestPnjl();
			$data['latest_pembelian']		= $this->dashboard_model->getLatestPmbl();

			$chart['grafik']			= $this->dashboard_model->getGrafik();

			echo view('dashboard/karyawan', $data);
			echo view('_partials/footer', $chart);
			echo view('_partials/sidebar/karyawan');
		} 
    }    
}