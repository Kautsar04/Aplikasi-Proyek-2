<?php echo view('_partials/header'); ?>

<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Tambah Penjualan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah Penjualan</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php 
            $inputs = session()->getFlashdata('inputs');
            $errors = session()->getFlashdata('errors');
            if(!empty($errors)){ ?>
            <div class="alert alert-danger" role="alert">
              Whoops! Ada kesalahan saat input data, yaitu:
              <ul>
              <?php foreach ($errors as $error) : ?>
                  <li><?= esc($error) ?></li>
              <?php endforeach ?>
              </ul>
            </div>
          <?php } ?>
          <?php echo form_open_multipart('penjualan/store'); ?>
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <?php 
                      echo form_label('Nama Konsumen');
                      $nama_konsumen = [
                        'type'  => 'text',
                        'name'  => 'nama_konsumen',
                        'id'    => 'nama_konsumen',
                        'value' => $inputs['nama_konsumen'],
                        'class' => 'form-control',
                        'placeholder' => 'Nama Konsumen'
                      ];
                      echo form_input($nama_konsumen); 
                    ?>
                  </div>
                  <div class="form-group">
                    <?php 
                      echo form_label('Tanggal Penjualan');
                      $tanggal_penjualan = [
                        'type'  => 'date',
                        'name'  => 'tanggal_penjualan',
                        'id'    => 'tanggal_penjualan',
                        'value' => $inputs['tanggal_penjualan'],
                        'class' => 'form-control',
                        'placeholder' => 'Tanggal Penjualan'
                      ];
                      echo form_input($tanggal_penjualan); 
                    ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <?php 
                      echo form_label('Total Penjualan');
                      $total_penjualan = [
                        'type'  => 'number',
                        'name'  => 'total_penjualan',
                        'id'    => 'total_penjualan',
                        'value' => $inputs['total_penjualan'],
                        'class' => 'form-control',
                        'placeholder' => 'Total Penjualan'
                      ];
                      echo form_input($total_penjualan); 
                    ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <?php 
                      echo form_label('Total Pemasukan');
                      $total_harga = [
                        'type'  => 'number',
                        'name'  => 'total_harga',
                        'id'    => 'total_harga',
                        'value' => $inputs['total_harga'],
                        'class' => 'form-control',
                        'placeholder' => 'Total Pemasukan'
                      ];
                      echo form_input($total_harga); 
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo base_url('penjualan'); ?>" class="btn btn-outline-info">Kembali</a>
                <button type="submit" class="btn btn-primary float-right">Simpan</button>
            </div>
          </div>
          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo view('_partials/footer'); ?>