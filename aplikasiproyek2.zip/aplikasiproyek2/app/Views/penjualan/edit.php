<?php echo view('_partials/header'); ?>

<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Edit Penjualan</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Edit Penjualan</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php 
            $inputs = session()->getFlashdata('inputs');
            $errors = session()->getFlashdata('errors');
            if(!empty($errors)){ ?>
            <div class="alert alert-danger" role="alert">
              Whoops! Ada kesalahan saat input data, yaitu:
              <ul>
              <?php foreach ($errors as $error) : ?>
                  <li><?= esc($error) ?></li>
              <?php endforeach ?>
              </ul>
            </div>
          <?php } ?>
          <div class="card">
            <?php echo form_open_multipart('penjualan/update'); ?>
              <div class="card-header">Form Edit Penjualan</div>
              <div class="card-body">
                <?php echo form_hidden('id_penjualan', $penjualan['id_penjualan']); ?>
                <div class="row">
                  <div class="col-md-8">
                    <div class="form-group">
                      <?php echo form_label('Nama Konsumen', 'Nama Konsumen'); ?>
                      <?php echo form_input(['name' => 'nama_konsumen', 'id' => 'nama_konsumen','class' => 'form-control', 'placeholder' => 'Nama Konsumen']); ?>
                    </div>
                    <div class="form-group">
                      <?php echo form_label('Tanggal Penjualan', 'Tanggal Penjualan'); ?>
                      <?php echo form_input('tanggal_penjualan', $penjualan['tanggal_penjualan'], ['class' => 'form-control', 'placeholder' => 'Tanggal Penjualan', 'type' => 'date']); ?>
                    </div>
                    <div class="form-group">
                      <?php echo form_label('Total Penjualan', 'Total Penjualan'); ?>
                      <?php echo form_input('total_penjualan', $penjualan['total_penjualan'], ['class' => 'form-control', 'placeholder' => 'Total Penjualan', 'type' => 'number']); ?>
                    </div>
                    <div class="form-group">
                      <?php echo form_label('Total Harga', 'Total Harga'); ?>
                      <?php echo form_input('total_harga', $penjualan['total_harga'], ['class' => 'form-control', 'placeholder' => 'Total Harga', 'type' => 'number']); ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer">
                  <a href="<?php echo base_url('penjualan'); ?>" class="btn btn-outline-info">Back</a>
                  <button type="submit" class="btn btn-primary float-right">Update</button>
              </div>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo view('_partials/footer'); ?>