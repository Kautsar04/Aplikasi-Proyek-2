<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo base_url('/'); ?>" class="brand-link">
        <i class="fas fa-store"></i>
      <span class="brand-text font-weight-light">Aplikasi pencatatan</span>
    </a>

    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
            <i class="fas fa-user fa-2x" style="color: gray"></i>
            </div>
            <div class="info">
                <a href="<?php echo base_url('/'); ?>" class="d-block">Selamat datang</a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo base_url('/'); ?>" class="nav-link">
                        <i class="nav-icon fas fa-th"></i>
                        <p>Dashboard Admin</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url('auth/users'); ?>" class="nav-link">
                        <i class="fas fa-users" style="color: red"></i>
                        <p>Kelola User</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url('barang'); ?>" class="nav-link">
                        <i class="fas fa-box-open" style="color: blue"></i>
                        <p>Kelola Barang</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url('penjualan'); ?>" class="nav-link">
                        <i class="fas fa-balance-scale-right" style="color: orange"></i>
                        <p>Tampil Penjualan</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url('pembelian'); ?>" class="nav-link">
                        <i class="fas fa-balance-scale-left" style="color: purple"></i>
                        <p>Tampil Pembelian</p>
                    </a>
                </li>
                <li class="nav-header">ACCOUNT</li>
                <li class="nav-item">
                    <a href="<?php echo base_url('auth/logout'); ?>" class="nav-link">
                        <i class="nav-icon far fa-circle text-danger"></i>
                        <p class="text">Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>