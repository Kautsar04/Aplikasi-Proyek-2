<?php echo view('_partials/header'); ?>

<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Tambah Pembelian</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah Pembelian</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php 
            $inputs = session()->getFlashdata('inputs');
            $errors = session()->getFlashdata('errors');
            if(!empty($errors)){ ?>
            <div class="alert alert-danger" role="alert">
              Whoops! Ada kesalahan saat input data, yaitu:
              <ul>
              <?php foreach ($errors as $error) : ?>
                  <li><?= esc($error) ?></li>
              <?php endforeach ?>
              </ul>
            </div>
          <?php } ?>
          <?php echo form_open_multipart('pembelian/store'); ?>
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                <div class="form-group"> 
                    <?php 
                      echo form_label('barang', 'barang');
                      echo form_dropdown('id_barang', $barang, $inputs['id_barang'], ['class' => 'form-control']); 
                    ?>
                  </div>
                <div class="form-group">
                    <?php 
                      echo form_label('Nama Suplier');
                      $nama_suplier = [
                        'type'  => 'text',
                        'name'  => 'nama_suplier',
                        'id'    => 'nama_suplier',
                        'value' => $inputs['nama_suplier'],
                        'class' => 'form-control',
                        'placeholder' => 'Nama Suplier'
                      ];
                      echo form_input($nama_suplier); 
                    ?>
                  </div>
                  <div class="form-group">
                    <?php 
                      echo form_label('Tanggal Pembelian');
                      $tanggal_pembelian = [
                        'type'  => 'date',
                        'name'  => 'tanggal_pembelian',
                        'id'    => 'tanggal_pembelian',
                        'value' => $inputs['tanggal_pembelian'],
                        'class' => 'form-control',
                        'placeholder' => 'Tanggal Pembelian'
                      ];
                      echo form_input($tanggal_pembelian); 
                    ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <?php 
                      echo form_label('Total Pembelian');
                      $total_pembelian = [
                        'type'  => 'number',
                        'name'  => 'total_pembelian',
                        'id'    => 'total_pembelian',
                        'value' => $inputs['total_pembelian'],
                        'class' => 'form-control',
                        'placeholder' => 'Total Pembelian'
                      ];
                      echo form_input($total_pembelian); 
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo base_url('pembelian'); ?>" class="btn btn-outline-info">Kembali</a>
                <button type="submit" class="btn btn-primary float-right">Simpan</button>
            </div>
          </div>
          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo view('_partials/footer'); ?>