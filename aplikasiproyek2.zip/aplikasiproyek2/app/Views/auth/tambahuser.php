<?php echo view('_partials/header'); ?>
<?php echo view('_partials/sidebar/admin'); ?>

<body class="hold-transition login-page">
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Tambah User</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah User</li>
          </ol>
        </div>
      </div>
    </div>
  </div> 

  <div class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
            <form action="<?php echo base_url('auth/proses_tambahuser'); ?>" method="post">
              <div class="card">
                <div class="card-body">
                <?php 
                  $inputs = session()->getFlashdata('inputs');
                  $errors = session()->getFlashdata('errors');
                  if(!empty($errors)){ ?>
                  <div class="alert alert-danger" role="alert">
                    Whoops! Ada kesalahan saat input data, yaitu:
                    <ul>
                    <?php foreach ($errors as $error) : ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach ?>
                    </ul>
                  </div>
                  <?php } ?>

                  <div class="form-group">
                      <label for="">Username</label>
                      <input type="text" class="form-control" name="username" placeholder="Masukan username" value="<?php echo $inputs['username']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="">Nama</label>
                      <input type="text" class="form-control" name="name" placeholder="Masukan nama" value="<?php echo $inputs['name']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="">Email</label>
                      <input type="email" class="form-control" name="email" placeholder="Masukan email" value="<?php echo $inputs['email']; ?>">
                  </div>
                  <div class="form-group">
                      <select name="level" id="" class="form-control">
                          <option value="">Pilih Level</option>
                          <option <?php echo $inputs['level'] == "Admin" ? "selected" : ""; ?> value="Admin">Admin</option>
                          <option <?php echo $inputs['level'] == "User" ? "selected" : ""; ?> value="User">User</option>
                      </select>
                  </div>
                  <div class="form-group">
                      <label for="">Password</label>
                      <input type="password" class="form-control" name="password" placeholder="Masukan Password" value="<?php echo $inputs['password']; ?>">
                  </div>
                  <div class="form-group">
                      <label for="">Confirm Password</label>
                      <input type="password" class="form-control" name="confirm_password" placeholder="Masukan confirm password" value="<?php echo $inputs['confirm_password']; ?>">
                  </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo base_url('auth/users'); ?>" class="btn btn-outline-info">Back</a>
                    <button type="submit" class="btn btn-primary float-right">Simpan</button>
                </div>
              </div>
            </form>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo base_url('themes/plugins'); ?>/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('themes/plugins'); ?>/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('themes/dist'); ?>/js/adminlte.min.js"></script>
</body>
</html>