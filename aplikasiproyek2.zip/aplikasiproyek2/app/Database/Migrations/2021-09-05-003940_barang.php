<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Barang extends Migration
{
	public function up()
	{
		$this->db->enableForeignKeyChecks();
		$this->forge->addField([
			'id_barang'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'auto_increment' 	=> TRUE
			],
			'nama_barang'			=> [
				'type'           	=> 'VARCHAR',
				'constraint'     	=> 20,
			],
			'total_harga'     		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
			'stok'     		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
		]);
		$this->forge->addKey('id_barang', TRUE);
		$this->forge->createTable('barang');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		//
	}
}
