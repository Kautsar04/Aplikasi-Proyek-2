<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Suplier extends Migration
{
	public function up()
	{
		$this->db->enableForeignKeyChecks();
		$this->forge->addField([
			'id_suplier'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'auto_increment' 	=> TRUE
			],
			'nama_suplier'			=> [
				'type'           	=> 'VARCHAR',
				'constraint'     	=> 20,
			],
			'alamat'			=> [
				'type'           	=> 'VARCHAR',
				'constraint'     	=> 20,
			],
			'no_hp'     			=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
		]);
		$this->forge->addKey('id_suplier', TRUE);
		$this->forge->createTable('suplier');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		//
	}
}
