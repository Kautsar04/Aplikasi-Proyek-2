<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Konsumen extends Migration
{
	public function up()
	{
		$this->db->enableForeignKeyChecks();
		$this->forge->addField([
			'id_konsumen'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'auto_increment' 	=> TRUE
			],
			'nama_konsumen'			=> [
				'type'           	=> 'VARCHAR',
				'constraint'     	=> 20,
			],
			'alamat'			=> [
				'type'           	=> 'VARCHAR',
				'constraint'     	=> 20,
			],
			'no_hp'     			=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
		]);
		$this->forge->addKey('id_konsumen', TRUE);
		$this->forge->createTable('konsumen');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		//
	}
}
