<?php namespace App\Database\Migrations\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pembelian extends Migration
{
	public function up()
	{
		$this->db->enableForeignKeyChecks();
		$this->forge->addField([
			'id_pembelian'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'auto_increment' 	=> TRUE
			],
			'id_barang'				=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'null'				=> TRUE
			],
			'id_suplier'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'null'				=> TRUE
			],
			'tanggal_pembelian' 	=> [
				'type'           	=> 'DATE'
			],
			'total_pembelian'		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
			'total_harga'     		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
		]);
		$this->forge->addKey('id_pembelian', TRUE);
		$this->forge->addForeignKey('id_barang','barang','id_barang','CASCADE','CASCADE');
		$this->forge->addForeignKey('id_suplier','suplier','id_suplier','CASCADE','CASCADE');
		$this->forge->createTable('pembelian');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		//
	}
}