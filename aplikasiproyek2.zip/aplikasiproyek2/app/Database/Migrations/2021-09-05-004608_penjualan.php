<?php namespace App\Database\Migrations\Database\Migrations;

use CodeIgniter\Database\Migration;

class Penjualan extends Migration
{
	public function up()
	{
		$this->db->enableForeignKeyChecks();
		$this->forge->addField([
			'id_penjualan'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'auto_increment' 	=> TRUE
			],
			'id_konsumen'			=> [
				'type'           	=> 'BIGINT',
				'constraint'     	=> 20,
				'unsigned'       	=> TRUE,
				'null'				=> TRUE
			],
			'tanggal_penjualan' 	=> [
				'type'           	=> 'DATE'
			],
			'total_penjualan'		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
			'total_harga'     		=> [
				'type'           	=> 'INT',
				'constraint'     	=> '11',
			],
		]);
		$this->forge->addKey('id_penjualan', TRUE);
		$this->forge->addForeignKey('id_konsumen','konsumen','id_konsumen','CASCADE','CASCADE');
		$this->forge->createTable('penjualan');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		//
	}
}