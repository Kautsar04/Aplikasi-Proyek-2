<?php namespace App\Database\Seeds;

class AdminSeeder extends \CodeIgniter\Database\Seeder
{
    public function run()
    {
        $data = [
            [
            'username'  => 'penanggungjawab',
            'name'      => 'penanggungjawab',
            'email'     => 'penaggungjawab@example.com',
            'password'  => 'penanggungjawab',
            'level'     => 'Admin'
            ],
            [
            'username'  => 'karyawan',
            'name'      => 'karyawan',
            'email'     => 'karyawan@example.com',
            'password'  => 'karyawan',
            'level'     => 'User'
            ]
        ];
        foreach($data as $data){
			// insert semua data ke tabel
			$this->db->table('users')->insert($data);
        }
    }
} 