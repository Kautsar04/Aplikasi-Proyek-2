<?php namespace Config;

class Validation
{
	public $ruleSets = [
		\CodeIgniter\Validation\Rules::class,
		\CodeIgniter\Validation\FormatRules::class,
		\CodeIgniter\Validation\FileRules::class,
		\CodeIgniter\Validation\CreditCardRules::class,
	];

	public $templates = [
		'list'   => 'CodeIgniter\Validation\Views\list',
		'single' => 'CodeIgniter\Validation\Views\single',
	];
	
	public $barang = [
		'nama_barang'         => 'required',
		'harga'      		  => 'required',
		'stok'          	  => 'required'
	];

	public $barang_errors = [
		'nama_barang'		=> [
			'required' 		=> 'Nama barang wajib diisi.'
		],
		'harga' 			=> [
			'required' 		=> 'Harga barang wajib diisi.'
		],
		'stok'  			=> [
			'required' 		=> 'stock barang wajib diisi.'
		]
	];

	public $ceksuplier = [
		'nama_suplier'         	=> 'is_unique[suplier.nama_suplier]'
	];

	public $tambahpembelian = [
		'id_barang'         	=> 'required',
		'nama_suplier' 			=> 'required',
		'tanggal_pembelian' 	=> 'required',
		'total_pembelian' 		=> 'required'
	];

	public $tambahpembelian_errors = [
		'id_barang'		=> [
			'required' 		=> 'Nama barang wajib diisi.'
		],
		'nama_suplier'		=> [
			'required' 		=> 'Nama suplier wajib diisi.'
		],
		'tanggal_pembelian' => [
			'required' 		=> 'Tanggal Pembelian wajib diisi.'
		],
		'total_pembelian' 	=> [
			'required' 		=> 'Total Pembelian wajib diisi.'
		]
	];

	public $cekbarang = [
		'nama_barang'         	=> 'is_unique[barang.nama_barang]'
	];

	public $cekkonsumen = [
		'nama_konsumen'         	=> 'is_unique[konsumen.nama_konsumen]'
	];

	public $tambahpenjualan = [
		'nama_konsumen'         => 'required',
		'tanggal_penjualan' 	=> 'required',
		'total_penjualan' 		=> 'required',
		'total_harga' 			=> 'required'
	];

	public $tambahpenjualan_errors = [
		'nama_konsumen'		=> [
			'required' 		=> 'Nama konsumen wajib diisi.'
		],
		'tanggal_penjualan' => [
			'required' 		=> 'Tanggal penjualan wajib diisi.'
		],
		'total_penjualan' => [
			'required' 		=> 'Total penjualan wajib diisi.'
		],
		'total_harga' 		=> [
			'required' 		=> 'Pengeluaran wajib diisi.'
		]
	];

	public $penjualan = [
		'trx_file'         => 'uploaded[trx_file]|ext_in[trx_file,xls,xlsx]|max_size[trx_file,1000]',
	];

	public $penjualan_errors = [
		'trx_file'=> [
			'ext_in' 	=> 'File Excel hanya boleh diisi dengan xls atau xlsx.',
			'max_size'	=> 'File Excel product maksimal 1mb',
			'uploaded'	=> 'File Excel product wajib diisi'
		]
	];

	public $pembelian = [
		'trx_file'         => 'uploaded[trx_file]|ext_in[trx_file,xls,xlsx]|max_size[trx_file,1000]',
	];

	public $pembelian_errors = [
		'trx_file'=> [
			'ext_in' 	=> 'File Excel hanya boleh diisi dengan xls atau xlsx.',
			'max_size'	=> 'File Excel product maksimal 1mb',
			'uploaded'	=> 'File Excel product wajib diisi'
		]
	];

	public $authlogin = [
		'email'         => 'required|valid_email',
		'password' 		=> 'required'
	];

	public $authlogin_errors = [
		'email'=> [
			'required' 	=> 'Email wajib diisi.',
			'valid_email'	=> 'Email tidak valid'
		],
		'password'=> [
			'required' 	=> 'Password wajib diisi.'
		]
	];

	public $authtambahuser = [
		'email'         	=> 'required|valid_email|is_unique[users.email]',
		'username' 			=> 'required|alpha_numeric|is_unique[users.username]|max_length[35]',
		'name' 				=> 'required|alpha_numeric_space|min_length[3]|max_length[35]',
		'level' 				=> 'required',
		'password' 			=> 'required|string|max_length[35]',
		'confirm_password' 	=> 'required|string|matches[password]|max_length[35]',
	];

	public $authtambahuser_errors = [
		'email'=> [
			'required' 		=> 'Email wajib diisi',
			'valid_email'	=> 'Email tidak valid',
			'is_unique'		=> 'Email sudah terdaftar'
		],
		'username'=> [
			'required' 		=> 'Username wajib diisi',
			'alpha_numeric'	=> 'Username hanya boleh berisi huruf dan angka',
			'is_unique'		=> 'Username sudah terdaftar',
			'max_length'	=> 'Username maksimal 35 karakter'
		],
		'name'=> [
			'required' 				=> 'Name wajib diisi',
			'alpha_numeric_spaces'	=> 'Name hanya boleh berisi huruf, angka dan spasi',
			'min_length'			=> 'Name minimal 3 karakter',
			'max_length'			=> 'Name maksimal 35 karakter'
		],
		'level'=> [
			'required' 				=> 'Level wajib dipilih'
		],
		'password'=> [
			'required' 		=> 'Password wajib diisi',
			'string'		=> 'Password hanya boleh berisi huruf, angka, spasi dan karakter lain',
			'max_length'	=> 'Password maksimal 35 karakter'
		],
		'confirm_password'=> [
			'required' 		=> 'Konfirmasi password wajib diisi',
			'string'		=> 'Konfirmasi password hanya boleh berisi huruf, angka, spasi dan karakter lain',
			'matches'		=> 'Konfirmasi password tidak sama dengan password',
			'max_length'	=> 'Konfirmasi password maksimal 35 karakter'
		]
	];
}
